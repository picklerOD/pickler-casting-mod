# Pickler Clip Companion
# A game script can't press hotkeys or reach the network, so this small program does it. It watches
# the mod's saved config file; each goal raises clipEventId there, and this then asks OBS (Replay
# Buffer, through OBS's built-in WebSocket) or Medal to save a clip. Everything is local.
param(
	[string]$SettingsPath = (Join-Path $PSScriptRoot 'companion-settings.json'),
	[int]$MaxSeconds = 0   # stop after this long (0 = run until closed); used for testing
)

function Write-Status([string]$message, [string]$color = 'Gray') {
	Write-Host ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $message) -ForegroundColor $color
}

function Get-Sha256Base64([string]$text) {
	$sha = [Security.Cryptography.SHA256]::Create()
	try { return [Convert]::ToBase64String($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($text))) }
	finally { $sha.Dispose() }
}

function Get-ObsAuth([string]$password, [string]$salt, [string]$challenge) {
	return Get-Sha256Base64 ((Get-Sha256Base64 ($password + $salt)) + $challenge)
}

function Send-WsText($socket, [string]$text, [int]$timeoutMs) {
	$bytes = [Text.Encoding]::UTF8.GetBytes($text)
	$segment = New-Object System.ArraySegment[byte] -ArgumentList @(, $bytes)
	$task = $socket.SendAsync($segment, [Net.WebSockets.WebSocketMessageType]::Text, $true, [Threading.CancellationToken]::None)
	if (-not $task.Wait($timeoutMs)) { throw 'Timed out sending to OBS' }
}

function Receive-WsJson($socket, [int]$timeoutMs) {
	$buffer = New-Object byte[] 65536
	$stream = New-Object IO.MemoryStream
	do {
		$segment = New-Object System.ArraySegment[byte] -ArgumentList @(, $buffer)
		$task = $socket.ReceiveAsync($segment, [Threading.CancellationToken]::None)
		if (-not $task.Wait($timeoutMs)) { throw 'Timed out waiting for OBS' }
		if ($task.Result.MessageType -eq [Net.WebSockets.WebSocketMessageType]::Close) { throw 'OBS closed the connection (wrong password?)' }
		$stream.Write($buffer, 0, $task.Result.Count)
	} while (-not $task.Result.EndOfMessage)
	return ([Text.Encoding]::UTF8.GetString($stream.ToArray()) | ConvertFrom-Json)
}

function Invoke-ObsRequest($socket, [string]$requestType, [int]$timeoutMs) {
	$id = [guid]::NewGuid().ToString()
	$message = @{ op = 6; d = @{ requestType = $requestType; requestId = $id } } | ConvertTo-Json -Depth 5 -Compress
	Send-WsText $socket $message $timeoutMs
	while ($true) {
		$reply = Receive-WsJson $socket $timeoutMs
		if ($reply.op -eq 7 -and $reply.d.requestId -eq $id) { return $reply.d }
	}
}

# Connects, logs in, runs the requests, and always closes. Throws a readable error on failure.
function Invoke-Obs($settings, [string[]]$requestTypes) {
	$socket = New-Object Net.WebSockets.ClientWebSocket
	$timeoutMs = 4000
	try {
		$uri = [Uri]("ws://{0}:{1}" -f $settings.obsHost, $settings.obsPort)
		$connect = $socket.ConnectAsync($uri, [Threading.CancellationToken]::None)
		try { $connected = $connect.Wait($timeoutMs) }
		catch { throw "Can't reach OBS at $uri. Is OBS open, with Tools > WebSocket Server Settings enabled?" }
		if (-not $connected) { throw "Can't reach OBS at $uri (timed out)." }
		$hello = Receive-WsJson $socket $timeoutMs
		$identify = @{ rpcVersion = 1 }
		if ($hello.d.authentication) {
			$identify.authentication = Get-ObsAuth $settings.obsPassword $hello.d.authentication.salt $hello.d.authentication.challenge
		}
		Send-WsText $socket (@{ op = 1; d = $identify } | ConvertTo-Json -Depth 5 -Compress) $timeoutMs
		$identified = Receive-WsJson $socket $timeoutMs
		if ($identified.op -ne 2) { throw 'OBS did not accept the login.' }
		$results = @()
		foreach ($type in $requestTypes) { $results += Invoke-ObsRequest $socket $type $timeoutMs }
		return , $results
	}
	finally {
		if ($socket.State -eq [Net.WebSockets.WebSocketState]::Open) {
			try { [void]$socket.CloseAsync([Net.WebSockets.WebSocketCloseStatus]::NormalClosure, 'done', [Threading.CancellationToken]::None).Wait(1000) } catch {}
		}
		$socket.Dispose()
	}
}

function Save-ObsClip($settings) {
	$status = (Invoke-Obs $settings @('SaveReplayBuffer'))[0]
	if ($status.requestStatus.result) { Write-Status 'OBS saved the clip.' 'Green'; return }
	if ($status.requestStatus.code -eq 501) {
		Write-Status 'OBS Replay Buffer is not running, so nothing was saved. Starting it for the next goal.' 'Yellow'
		[void](Invoke-Obs $settings @('StartReplayBuffer'))
		return
	}
	Write-Status ("OBS refused: {0} {1}" -f $status.requestStatus.code, $status.requestStatus.comment) 'Yellow'
}

function Save-MedalClip($settings, [string]$team) {
	if ([string]::IsNullOrWhiteSpace($settings.medalPublicKey)) { throw 'medalPublicKey is empty in companion-settings.json.' }
	$body = @{ eventId = 'pickler_goal'; eventName = 'Goal'; triggerActions = @('SaveClip'); contextTags = @{ team = $team } } | ConvertTo-Json -Depth 5 -Compress
	try {
		[void](Invoke-RestMethod -Method Post -Uri 'http://localhost:12665/api/v1/event/invoke' -Headers @{ publicKey = $settings.medalPublicKey } -ContentType 'application/json' -Body $body -TimeoutSec 4)
	}
	catch { throw "Medal did not accept the request. Is Medal running? ($($_.Exception.Message))" }
	Write-Status 'Medal was asked to save a clip.' 'Green'
}

function Send-ClipHotkey($settings) {
	if ([string]::IsNullOrWhiteSpace($settings.hotkey)) { throw 'hotkey is empty in companion-settings.json.' }
	(New-Object -ComObject WScript.Shell).SendKeys($settings.hotkey)
	Write-Status "Pressed $($settings.hotkey)." 'Green'
}

function Invoke-Clip($settings, [string]$team) {
	switch ($settings.method) {
		'obs'    { Save-ObsClip $settings }
		'medal'  { Save-MedalClip $settings $team }
		'hotkey' { Send-ClipHotkey $settings }
		'obs+hotkey' {
			# a failure on one side must not stop the other from saving its clip
			try { Save-ObsClip $settings } catch { Write-Status "OBS clip not saved: $($_.Exception.Message)" 'Red' }
			Send-ClipHotkey $settings
		}
		default  { throw "Unknown method '$($settings.method)'. Use obs, medal, hotkey or obs+hotkey." }
	}
}

# The game may be mid-save: a read that fails just returns nothing, and the next poll tries again.
function Read-ModConfig([string]$path) {
	try {
		$raw = [IO.File]::ReadAllText($path)
		return ($raw | ConvertFrom-Json).customData
	}
	catch { return $null }
}

if (-not (Test-Path $SettingsPath)) { Write-Status "Settings file not found: $SettingsPath" 'Red'; exit 1 }
$settings = Get-Content $SettingsPath -Raw | ConvertFrom-Json
if ([IO.Path]::IsPathRooted($settings.configPath)) { $configPath = $settings.configPath }
else { $configPath = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot $settings.configPath)) }

Write-Status 'Pickler Clip Companion. Leave this window open while you cast; close it to stop.' 'Cyan'
Write-Status "Method: $($settings.method)   Watching: $configPath"
if (-not (Test-Path $configPath)) { Write-Status 'Config file not found yet. Load Pickler in the game once, then press SAVE SETTINGS.' 'Yellow' }

# Take the starting count before anything slow, so a goal during startup isn't missed. Clips from
# before this program started are ignored.
$lastId = $null
$startMod = Read-ModConfig $configPath
if ($startMod -and $null -ne $startMod.clipEventId) {
	$lastId = [long]$startMod.clipEventId
	Write-Status "Clip signals so far: $lastId"
}

if ($settings.method -like 'obs*') {
	try {
		$check = (Invoke-Obs $settings @('GetReplayBufferStatus'))[0]
		Write-Status 'Connected to OBS.' 'Green'
		if ($check.responseData.outputActive) { Write-Status 'Replay Buffer is running.' 'Green' }
		else {
			Write-Status 'Replay Buffer is off. Starting it...' 'Yellow'
			$start = (Invoke-Obs $settings @('StartReplayBuffer'))[0]
			if ($start.requestStatus.result) { Write-Status 'Replay Buffer started.' 'Green' }
			else { Write-Status 'Could not start it. Enable it in OBS: Settings > Output > Replay Buffer.' 'Yellow' }
		}
	}
	catch { Write-Status "$($_.Exception.Message) Will try again at the next goal." 'Yellow' }
}

$pending = New-Object System.Collections.ArrayList
$started = Get-Date
while ($MaxSeconds -le 0 -or ((Get-Date) - $started).TotalSeconds -lt $MaxSeconds) {
	$mod = Read-ModConfig $configPath
	if ($mod -and $null -ne $mod.clipEventId) {
		$id = [long]$mod.clipEventId
		if ($null -eq $lastId) {
			$lastId = $id
			Write-Status "Clip signals so far: $id"
		}
		elseif ($id -gt $lastId) {
			$lastId = $id
			$postSeconds = [double]$mod.clipPostSeconds
			Write-Status ("Goal ({0}). Saving in {1:0.#} s." -f $mod.clipEventTeam, $postSeconds) 'Cyan'
			[void]$pending.Add(@{ at = (Get-Date).AddSeconds($postSeconds); team = [string]$mod.clipEventTeam })
		}
		elseif ($id -lt $lastId) { $lastId = $id }
	}
	# a failure is reported and skipped: this program must keep running for the next goal
	foreach ($job in @($pending)) {
		if ((Get-Date) -ge $job.at) {
			$pending.Remove($job)
			try { Invoke-Clip $settings $job.team }
			catch { Write-Status "Clip not saved: $($_.Exception.Message)" 'Red' }
		}
	}
	Start-Sleep -Milliseconds 200
}
