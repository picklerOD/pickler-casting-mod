@echo off
title Pickler Clip Companion
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PicklerClipCompanion.ps1"
pause
